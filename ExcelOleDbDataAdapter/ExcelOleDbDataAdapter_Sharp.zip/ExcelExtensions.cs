﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelOleDbDataAdapter
{
    internal static class ExcelExtensions
    {
        public enum UseHeader
        {
            /// <summary>
            /// Indicates that the first row contains columnnames, no data
            /// </summary>
            /// <remarks></remarks>
            Yes,
            /// <summary>
            /// Indicates that the first row does not contain columnnames
            /// </summary>
            /// <remarks></remarks>
            No
        }
        public enum ExcelImex
        {
            TryScan = 0,
            Resolve = 1
        }

        public static void SetExcelConnectionString(this OleDbConnection sender, string FileName, UseHeader Header, ExcelImex IMEX)
        {

            string Mode = Convert.ToInt32(IMEX).ToString();
            var Builder = new OleDbConnectionStringBuilder { DataSource = FileName };
            if (Path.GetExtension(FileName).ToUpper() == ".XLSX")
            {
                Builder.Provider = "Microsoft.ACE.OLEDB.12.0";
                Builder.Add("Extended Properties", "Excel 12.0;IMEX=" + Mode + ";HDR=" + Header.ToString() + ";");
            }
            else
            {
                Builder.Provider = "Microsoft.Jet.OLEDB.4.0";
                Builder.Add("Extended Properties", "Excel 8.0;IMEX=" + Mode + ";HDR=" + Header.ToString() + ";");
            }

            sender.ConnectionString = Builder.ConnectionString;
        }
        /// <summary>
        /// Get column letter from ordinal
        /// </summary>
        /// <param name="pIndex"></param>
        /// <returns></returns>
        public static string ExcelColumnNameFromNumber(this int pIndex)
        {
            var chars = Enumerable.Range(0, 26).Select((i) => ((char)(Convert.ToInt32('A') + i)).ToString()).ToArray();

            pIndex -= 1;

            string columnName = null;
            var quotient = pIndex / 26;

            if (quotient > 0)
            {
                columnName = ExcelColumnNameFromNumber(quotient) + chars[pIndex % 26];
            }
            else
            {
                columnName = chars[pIndex % 26].ToString();
            }

            return columnName;

        }
        /// <summary>
        /// Convert excel column letter to it's ordinal position
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static int ExcelColumnNameToNumber(this string columnName)
        {
            if (string.IsNullOrEmpty(columnName))
            {
                throw new ArgumentNullException("columnName");
            }

            columnName = columnName.ToUpperInvariant();

            int sum = 0;

            for (int i = 0; i < columnName.Length; i++)
            {
                sum *= 26;
                sum += (columnName[i] - 'A' + 1);
            }

            return sum;
        }


    }

}
